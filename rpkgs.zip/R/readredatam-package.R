#' @title COMPLETE
#'
#' @description
#' COMPLETE
#'
#' @name readredatam-package
#' @useDynLib readredatam, .registration = TRUE
"_PACKAGE"
